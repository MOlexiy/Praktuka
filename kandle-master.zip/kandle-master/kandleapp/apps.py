from django.apps import AppConfig


class KandleappConfig(AppConfig):
    name = 'kandleapp'
